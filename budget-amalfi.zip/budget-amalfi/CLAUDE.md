# Budget Voyage — Instructions Claude

## Contexte du projet

Ce projet contient une **application web de suivi de dépenses de voyage** utilisée à répétition : **chaque nouvelle conversation dans ce projet correspond à un voyage vers un endroit différent** (ex. Côte Amalfitaine, Lisbonne, Kyoto…).

Le fichier `budget-voyage.html` est le **modèle/outil** commun à tous les voyages. Les données de chaque voyage restent stockées localement dans le navigateur de l'utilisateur (localStorage) et/ou exportées vers Google Drive — elles ne sont pas dans le fichier.

## Réponses aux demandes courantes

### « Relance-moi l'appli » / « Redonne-moi l'appli »

L'utilisateur veut recevoir le fichier HTML prêt à ouvrir pour démarrer le suivi d'un nouveau voyage.

1. Copier `budget-voyage.html` de la base de connaissances vers `/mnt/user-data/outputs/`.
2. Présenter le fichier avec `present_files`.
3. Si l'utilisateur a mentionné une destination, proposer de personnaliser le `tripName` dans le code avant livraison (une modif `str_replace` ciblée de la ligne `tripName: 'Côte Amalfitaine'` suffit).
4. **Ne pas regénérer le code** ni proposer de refonte.

### Correctif ou nouvelle fonctionnalité

Modifier le fichier via `str_replace` ciblés en respectant les règles ci-dessous, puis présenter le résultat. Rappeler à l'utilisateur **qu'il doit remplacer le fichier dans la base de connaissances du projet** pour que les prochains voyages bénéficient du correctif.

## Règles de modification

- **Un seul fichier HTML auto-suffisant.** Pas de dépendances externes, pas de CDN, pas de frameworks.
- **Mobile-first.** Cibles tactiles min. 40×40 px. Pas de hover-only.
- **Éviter `confirm()` / `alert()` / `prompt()`** — ces dialogues natifs sont peu fiables en mode PWA iOS. Préférer des confirmations en deux taps dans l'UI (le bouton change d'apparence + texte au 1er tap, action au 2e tap, reset automatique après 3–4 s).
- **Format français pour les montants.** Accepter virgule ET point. La fonction `parseAmt(el)` fait le remplacement.
- **Persistance.** Toute modification de `state` doit appeler `saveData()` pour écrire dans `localStorage`.
- **Rétro-compatibilité des sauvegardes.** Le format JSON exporté (`generateBackupText`) doit rester lisible par `importFromText` même après ajout de nouveaux champs — les utilisateurs peuvent restaurer d'anciennes sauvegardes.
- **Ne jamais casser le mode « copier-coller vers Drive »** : c'est la seule méthode de sauvegarde hors-appareil.

## Structure du state

```js
state = {
  tripName: 'Côte Amalfitaine',          // nom affiché du voyage
  budgetCash: 0, budgetCard: 0,           // budgets initiaux
  topUps: [{ id, mode, amount, note, date }],
  expenses: [{ id, amount, mode, category, subcategory, dayId, note }],
  days: [{ id, label, desc }],
  view: 'dashboard'|'expenses'|'categories'|'days',
  modal: null | 'tripName' | 'budget' | 'topup' | 'expense' | 'editExpense' | 'dayMgr' | 'backup'
}
```

`mode` vaut `'cash'` ou `'card'`. IDs générés par `Date.now() + Math.random()`. Clés localStorage : `travel_expenses_v4` et `travel_expenses_last_export_v4`.

## Rubriques

Définies dans `CATEGORIES` : chaque rubrique a une icône emoji, une couleur et une liste de sous-rubriques. **Ne pas renommer les clés** sans plan de migration — les dépenses existantes s'y réfèrent par chaîne. Ajouter des sous-rubriques est sans risque.

## Fonctions clés

- `render()` : redessine toute l'UI à partir du state (rendu via `innerHTML`, pas de framework)
- `saveData()` : persiste dans localStorage + flash « Sauvegardé »
- `parseAmt(el)` : lit un montant en acceptant virgule ou point
- `computeTotals()`, `computeByCategory()`, `computeByDay()` : agrégations
- `generateBackupText()` / `importFromText()` : export/import JSON
- `openModal(name)` / `closeModal()` : ouverture/fermeture des modales

## Historique des modifications de la version actuelle

- Boutons modifier/supprimer dans la liste des dépenses agrandis (min 40×40 px, fond gris clair, poubelle rouge)
- Les inputs de montant acceptent la virgule française (`12,50` ou `12.50`)
- Bouton « Supprimer » ajouté dans le modal d'édition d'une dépense, avec confirmation en deux taps (pas de `confirm()` natif)
